# Executive Analytics Dashboard Design Guidelines
## Royal Caribbean Group Talent Acquisition Intelligence Platform

## Design Approach

**Hybrid Excellence Strategy**: Combine Linear's sophisticated minimalism with Tableau's data visualization clarity and enterprise dashboard best practices. Create a premium analytics experience that balances executive-level polish with functional depth.

## Typography System

**Font Stack**:
- Primary: Inter (via Google Fonts) - numerical data, metrics, labels
- Secondary: Manrope (via Google Fonts) - headings, section titles
- Monospace: JetBrains Mono - timestamps, data codes

**Hierarchy**:
- Dashboard Title: text-2xl font-semibold (Manrope)
- Section Headers: text-lg font-semibold (Manrope)
- KPI Values: text-4xl font-bold (Inter) with tabular-nums
- KPI Labels: text-sm font-medium text-gray-500 (Inter)
- Chart Labels: text-xs font-medium (Inter)
- Supporting Text: text-sm (Inter)
- Metric Deltas: text-sm font-semibold with directional indicators

## Layout Architecture

**Spacing Primitives**: Use Tailwind units of 3, 4, 6, 8, 12, 16 exclusively for consistent rhythm.

**Grid System**:
- Dashboard container: max-w-[1920px] mx-auto px-6
- Primary KPI row: grid grid-cols-4 gap-6 (4 hero metrics)
- Analytics sections: grid grid-cols-2 lg:grid-cols-3 gap-6
- Full-width visualizations: col-span-full
- Sidebar filters: w-72 fixed left-0 h-screen

**Vertical Rhythm**:
- Dashboard padding: p-6
- Section spacing: space-y-6 between major blocks
- Card internal padding: p-6
- Metric card padding: p-8 (generous for executive viewing)

## Component Library

### Executive KPI Cards
Premium stat cards with sophisticated visual treatment:
- Large numerical display with tabular-nums
- Trend indicator (↑↓) with percentage delta
- Sparkline mini-chart showing 30-day trend
- Period comparison label (vs. Previous Period)
- Subtle gradient border-top accent
- Glassmorphic background with backdrop-blur

### Advanced Chart Components

**Traffic Analytics**:
- Multi-line time series with interactive legends
- Area charts with gradient fills for stacked metrics
- Candlestick-style charts for conversion ranges

**Funnel Visualization**:
- Horizontal bar funnel with conversion percentages
- Sankey diagram for candidate flow paths
- Waterfall charts for stage-by-stage dropoff

**Intelligence Layers**:
- Gauge charts for KPI progress (arc-style, 0-100%)
- Heatmap calendar for activity patterns
- Bubble charts for multi-dimensional analysis
- Donut charts for composition breakdowns

### Navigation & Controls

**Top Navigation Bar**:
- Fixed position with backdrop-blur
- Logo left, primary metrics center, user profile right
- Date range picker with presets (7D, 30D, QTD, YTD)
- Export controls (PDF, Excel, PNG)
- Real-time indicator with pulse animation

**Filter Sidebar**:
- Collapsible sections for dimension filtering
- Multi-select dropdowns for job categories, locations, sources
- Saved view presets for different executive personas
- Clear all filters action

### Data Visualization Standards

**Chart Framework**: Use Chart.js via CDN for consistency

**Interaction Patterns**:
- Hover tooltips with detailed breakdowns
- Click-to-drill-down on aggregated metrics
- Brush selection for time range zooming
- Cross-filtering between related charts

**Visual Encoding**:
- Line thickness: 2-3px for primary data series
- Grid lines: subtle, low opacity (0.1)
- Axis labels: rotated 45° only when necessary
- Legend position: top-right for horizontal space efficiency

### Alert & Insight Modules

**AI-Powered Insights Panel**:
- Prominent placement below hero KPIs
- Anomaly detection badges with severity indicators
- Natural language summaries of key findings
- Recommended actions in bullet format
- Dismissible with "Mark as Read" functionality

**Performance Alerts**:
- Toast notifications for real-time anomalies
- Badge counters on affected metric cards
- Alert history sidebar (slide-in from right)

## Layout Composition

### Dashboard Structure (Top to Bottom):

1. **Header Bar** (h-16): Logo, global controls, user menu
2. **Hero Metrics Row** (h-48): 4 primary KPIs in premium cards
3. **Insights Panel** (h-auto): AI-generated findings and alerts
4. **Analytics Grid** (2-3 column): Traffic, funnel, engagement sections
5. **Deep Dive Modules** (full-width): Shareholder intelligence, predictive analytics
6. **Behavior Analytics** (2-column): Journey mapping, device breakdown

### Responsive Breakpoints:
- Desktop (1920px+): Full 3-column grid with sidebar
- Laptop (1440px): 2-column grid, collapsible sidebar
- Tablet (1024px): Single column stack, hamburger menu

## Micro-interactions

**Minimal Animation Strategy**:
- KPI counter animations on initial load (count-up effect, 1.5s duration)
- Chart drawing animations (500ms stagger)
- Smooth transitions for filter applications (300ms ease-out)
- Skeleton loading states for async data
- No hover animations on charts (performance priority)

## Accessibility Implementation

- ARIA labels for all chart elements
- Keyboard navigation for all interactive controls
- Focus indicators with 2px outline offset
- Color-blind safe palettes (use patterns/textures as backups)
- Screen reader descriptions for visual-only insights
- Minimum touch targets: 44x44px for all controls

## Data Presentation Standards

**Number Formatting**:
- Large metrics: Abbreviated (850K, 2.3M)
- Percentages: One decimal place (12.5%)
- Currency: Whole dollars ($850K)
- Dates: MMM DD, YYYY format
- Timestamps: HH:MM AM/PM with timezone indicator

**Comparison Indicators**:
- Always show period-over-period delta
- Use directional arrows with semantic meaning
- Include contextual benchmarks (industry avg, target)
- Highlight variance beyond ±10% thresholds

This framework creates a sophisticated, executive-grade analytics platform that prioritizes clarity, actionability, and visual excellence while maintaining enterprise-level functionality and accessibility standards.