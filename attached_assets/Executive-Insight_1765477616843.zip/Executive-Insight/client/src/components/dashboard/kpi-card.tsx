import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { KPIMetric } from "@shared/schema";

interface KPICardProps {
  metric: KPIMetric;
  index?: number;
}

export function KPICard({ metric, index = 0 }: KPICardProps) {
  const isPositive = metric.changeType === "increase";
  const isNegative = metric.changeType === "decrease";
  const isNeutral = metric.changeType === "neutral";

  return (
    <Card
      className={cn(
        "relative p-6 transition-all duration-300",
        "animate-fade-in",
        "group"
      )}
      style={{ animationDelay: `${index * 100}ms` }}
      data-testid={`kpi-card-${metric.id}`}
    >
      {/* Accent gradient top border */}
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary via-primary/80 to-primary/40 rounded-t-md" />
      
      <div className="space-y-4">
        {/* Label */}
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm font-medium text-muted-foreground truncate">
            {metric.label}
          </span>
          {metric.target && (
            <span className="text-xs text-muted-foreground/70">
              Target: {formatNumber(metric.target, metric.unit)}
            </span>
          )}
        </div>

        {/* Value */}
        <div className="flex items-end justify-between gap-4">
          <div className="space-y-1">
            <div 
              className="text-4xl font-bold tracking-tight tabular-nums animate-count-up"
              data-testid={`kpi-value-${metric.id}`}
            >
              {metric.formattedValue}
            </div>
            
            {/* Change indicator */}
            <div className="flex items-center gap-2">
              <div
                className={cn(
                  "flex items-center gap-1 text-sm font-semibold",
                  isPositive && "text-success",
                  isNegative && "text-destructive",
                  isNeutral && "text-muted-foreground"
                )}
              >
                {isPositive && <TrendingUp className="w-4 h-4" />}
                {isNegative && <TrendingDown className="w-4 h-4" />}
                {isNeutral && <Minus className="w-4 h-4" />}
                <span>
                  {isPositive ? "+" : ""}
                  {metric.change.toFixed(1)}%
                </span>
              </div>
              <span className="text-xs text-muted-foreground">
                vs. prev. period
              </span>
            </div>
          </div>

          {/* Sparkline */}
          <div className="w-24 h-12 flex-shrink-0">
            <Sparkline data={metric.trend} isPositive={isPositive} />
          </div>
        </div>

        {/* Progress bar for target */}
        {metric.target && (
          <div className="space-y-1">
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full transition-all duration-1000 ease-out",
                  isPositive ? "bg-success" : isNegative ? "bg-destructive" : "bg-primary"
                )}
                style={{
                  width: `${Math.min((metric.value / metric.target) * 100, 100)}%`,
                }}
              />
            </div>
            <div className="text-xs text-muted-foreground text-right">
              {((metric.value / metric.target) * 100).toFixed(0)}% of target
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}

function Sparkline({ data, isPositive }: { data: number[]; isPositive: boolean }) {
  if (!data.length) return null;
  
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  
  const points = data
    .map((value, i) => {
      const x = (i / (data.length - 1)) * 100;
      const y = 100 - ((value - min) / range) * 100;
      return `${x},${y}`;
    })
    .join(" ");
  
  const gradientId = `sparkline-gradient-${Math.random().toString(36).substr(2, 9)}`;
  
  return (
    <svg
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
      className="w-full h-full"
    >
      <defs>
        <linearGradient id={gradientId} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop
            offset="0%"
            stopColor={isPositive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
            stopOpacity="0.3"
          />
          <stop
            offset="100%"
            stopColor={isPositive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
            stopOpacity="0"
          />
        </linearGradient>
      </defs>
      
      {/* Area fill */}
      <polygon
        points={`0,100 ${points} 100,100`}
        fill={`url(#${gradientId})`}
      />
      
      {/* Line */}
      <polyline
        points={points}
        fill="none"
        stroke={isPositive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
      />
      
      {/* End point */}
      <circle
        cx={(data.length - 1) / (data.length - 1) * 100}
        cy={100 - ((data[data.length - 1] - min) / range) * 100}
        r="3"
        fill={isPositive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}

function formatNumber(value: number, unit?: string): string {
  if (unit === "$") {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value.toFixed(0)}`;
  }
  if (unit === "%") return `${value.toFixed(1)}%`;
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
  return value.toFixed(0);
}

export function KPICardSkeleton() {
  return (
    <Card className="relative p-6">
      <div className="absolute inset-x-0 top-0 h-1 bg-muted rounded-t-md animate-pulse" />
      <div className="space-y-4">
        <div className="h-4 bg-muted rounded w-1/2 animate-pulse" />
        <div className="flex items-end justify-between gap-4">
          <div className="space-y-2">
            <div className="h-10 bg-muted rounded w-32 animate-pulse" />
            <div className="h-4 bg-muted rounded w-24 animate-pulse" />
          </div>
          <div className="w-24 h-12 bg-muted rounded animate-pulse" />
        </div>
      </div>
    </Card>
  );
}
