import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { useState, useMemo } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import type { MultiSeriesData } from "@shared/schema";

interface TrafficChartProps {
  data: MultiSeriesData[];
  title?: string;
  className?: string;
}

type ChartType = "area" | "stacked";

export function TrafficChart({ data, title = "Traffic Analytics", className }: TrafficChartProps) {
  const [chartType, setChartType] = useState<ChartType>("area");

  const chartData = useMemo(() => {
    if (!data.length) return [];
    
    const dateMap = new Map<string, Record<string, number>>();
    
    data.forEach((series) => {
      series.data.forEach((point) => {
        const existing = dateMap.get(point.date) || { date: point.date };
        existing[series.name] = point.value;
        dateMap.set(point.date, existing);
      });
    });
    
    return Array.from(dateMap.values()).sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
  }, [data]);

  const formatXAxis = (tickItem: string) => {
    const date = new Date(tickItem);
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const formatYAxis = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    return value.toString();
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    
    const date = new Date(label);
    const formattedDate = date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });
    
    return (
      <div className="bg-popover border border-popover-border rounded-md p-3 shadow-lg">
        <p className="text-sm font-medium text-popover-foreground mb-2">
          {formattedDate}
        </p>
        <div className="space-y-1">
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-sm text-muted-foreground">{entry.name}</span>
              </div>
              <span className="text-sm font-semibold tabular-nums">
                {formatYAxis(entry.value)}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <Card className={cn("p-6", className)} data-testid="traffic-chart">
      <div className="flex items-center justify-between gap-4 mb-6 flex-wrap">
        <h3 className="text-lg font-semibold font-heading">{title}</h3>
        <Tabs value={chartType} onValueChange={(v) => setChartType(v as ChartType)}>
          <TabsList>
            <TabsTrigger value="area" data-testid="chart-type-area">
              Overlay
            </TabsTrigger>
            <TabsTrigger value="stacked" data-testid="chart-type-stacked">
              Stacked
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={chartData}
            margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
          >
            <defs>
              {data.map((series, index) => (
                <linearGradient
                  key={series.name}
                  id={`gradient-${index}`}
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop offset="0%" stopColor={series.color} stopOpacity={0.4} />
                  <stop offset="100%" stopColor={series.color} stopOpacity={0.05} />
                </linearGradient>
              ))}
            </defs>
            
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="hsl(var(--border))"
              strokeOpacity={0.5}
              vertical={false}
            />
            
            <XAxis
              dataKey="date"
              tickFormatter={formatXAxis}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
              axisLine={{ stroke: "hsl(var(--border))" }}
              tickLine={false}
              dy={10}
            />
            
            <YAxis
              tickFormatter={formatYAxis}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              dx={-10}
            />
            
            <Tooltip content={<CustomTooltip />} />
            
            <Legend
              verticalAlign="top"
              align="right"
              wrapperStyle={{ paddingBottom: 20 }}
              formatter={(value) => (
                <span className="text-sm text-foreground">{value}</span>
              )}
            />
            
            {data.map((series, index) => (
              <Area
                key={series.name}
                type="monotone"
                dataKey={series.name}
                stroke={series.color}
                strokeWidth={2}
                fill={`url(#gradient-${index})`}
                stackId={chartType === "stacked" ? "1" : undefined}
                animationDuration={800}
                animationBegin={index * 150}
              />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}

export function TrafficChartSkeleton() {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="h-6 bg-muted rounded w-40 animate-pulse" />
        <div className="h-8 bg-muted rounded w-32 animate-pulse" />
      </div>
      <div className="h-[300px] bg-muted/30 rounded animate-pulse" />
    </Card>
  );
}
