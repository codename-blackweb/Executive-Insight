import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, Minus, DollarSign, Target, Gauge, Award } from "lucide-react";
import { GaugeChart } from "./gauge-chart";
import type { ShareholderMetric } from "@shared/schema";

interface ShareholderMetricsProps {
  metrics: ShareholderMetric[];
  className?: string;
}

export function ShareholderMetrics({ metrics, className }: ShareholderMetricsProps) {
  const groupedMetrics = {
    roi: metrics.filter((m) => m.category === "roi"),
    efficiency: metrics.filter((m) => m.category === "efficiency"),
    cost: metrics.filter((m) => m.category === "cost"),
    quality: metrics.filter((m) => m.category === "quality"),
  };

  return (
    <Card className={cn("p-6", className)} data-testid="shareholder-metrics">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h3 className="text-lg font-semibold font-heading">
            Shareholder Intelligence
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            ROI metrics and strategic alignment indicators
          </p>
        </div>

        {/* Gauge row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.slice(0, 4).map((metric, index) => (
            <GaugeChart
              key={metric.id}
              value={metric.progress}
              label={metric.label}
              sublabel={metric.formattedValue}
              trend={metric.trend}
              colorScheme={getColorScheme(metric.category)}
              size="md"
            />
          ))}
        </div>

        {/* Detailed metrics grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {metrics.map((metric, index) => (
            <MetricRow key={metric.id} metric={metric} index={index} />
          ))}
        </div>
      </div>
    </Card>
  );
}

interface MetricRowProps {
  metric: ShareholderMetric;
  index: number;
}

function MetricRow({ metric, index }: MetricRowProps) {
  const getCategoryIcon = () => {
    switch (metric.category) {
      case "roi":
        return <DollarSign className="w-4 h-4" />;
      case "efficiency":
        return <Gauge className="w-4 h-4" />;
      case "cost":
        return <Target className="w-4 h-4" />;
      case "quality":
        return <Award className="w-4 h-4" />;
      default:
        return <Target className="w-4 h-4" />;
    }
  };

  const getTrendIcon = () => {
    switch (metric.trend) {
      case "up":
        return <TrendingUp className="w-4 h-4 text-success" />;
      case "down":
        return <TrendingDown className="w-4 h-4 text-destructive" />;
      default:
        return <Minus className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getCategoryColor = () => {
    switch (metric.category) {
      case "roi":
        return "bg-chart-1/10 text-chart-1 border-chart-1/20";
      case "efficiency":
        return "bg-chart-2/10 text-chart-2 border-chart-2/20";
      case "cost":
        return "bg-chart-3/10 text-chart-3 border-chart-3/20";
      case "quality":
        return "bg-chart-4/10 text-chart-4 border-chart-4/20";
      default:
        return "bg-muted text-muted-foreground border-muted";
    }
  };

  return (
    <div
      className={cn(
        "p-4 rounded-md border border-border bg-card/50 animate-fade-in",
        "hover:border-border/80 transition-colors"
      )}
      style={{ animationDelay: `${index * 50}ms` }}
      data-testid={`shareholder-metric-${metric.id}`}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={cn("p-2 rounded-md", getCategoryColor())}>
            {getCategoryIcon()}
          </div>
          <div>
            <p className="text-sm font-medium">{metric.label}</p>
            <p className="text-2xl font-bold tabular-nums mt-1">
              {metric.formattedValue}
            </p>
          </div>
        </div>
        
        <div className="flex flex-col items-end gap-2">
          {getTrendIcon()}
          <Badge variant="outline" className="text-xs">
            Target: {formatValue(metric.target, metric.category)}
          </Badge>
        </div>
      </div>

      {/* Progress bar */}
      <div className="mt-4 space-y-1">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Progress to target</span>
          <span className="font-medium">{metric.progress.toFixed(0)}%</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className={cn(
              "h-full rounded-full transition-all duration-1000 ease-out",
              metric.progress >= 100 ? "bg-success" :
              metric.progress >= 70 ? "bg-primary" :
              metric.progress >= 40 ? "bg-warning" : "bg-destructive"
            )}
            style={{ width: `${Math.min(metric.progress, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function getColorScheme(category: string): "primary" | "success" | "warning" | "destructive" {
  switch (category) {
    case "roi":
      return "primary";
    case "efficiency":
      return "success";
    case "cost":
      return "warning";
    case "quality":
      return "primary";
    default:
      return "primary";
  }
}

function formatValue(value: number, category: string): string {
  if (category === "cost") {
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value.toFixed(0)}`;
  }
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
  return value.toFixed(0);
}

export function ShareholderMetricsSkeleton() {
  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div className="space-y-2">
          <div className="h-6 bg-muted rounded w-48 animate-pulse" />
          <div className="h-4 bg-muted rounded w-64 animate-pulse" />
        </div>
        <div className="grid grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-muted/50 rounded animate-pulse" />
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-32 bg-muted/50 rounded animate-pulse" />
          ))}
        </div>
      </div>
    </Card>
  );
}
