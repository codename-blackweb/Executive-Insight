import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line,
} from "recharts";
import { Eye, Users, Clock, ArrowUpDown } from "lucide-react";
import type { EngagementMetric } from "@shared/schema";

interface EngagementChartProps {
  data: EngagementMetric[];
  className?: string;
}

type MetricView = "overview" | "sessions" | "duration";

export function EngagementChart({ data, className }: EngagementChartProps) {
  const [view, setView] = useState<MetricView>("overview");

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, "0")}`;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;

    return (
      <div className="bg-popover border border-popover-border rounded-md p-3 shadow-lg">
        <p className="font-medium text-sm mb-2">{label}</p>
        <div className="space-y-1">
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-sm text-muted-foreground">{entry.name}</span>
              </div>
              <span className="text-sm font-semibold tabular-nums">
                {entry.name === "Avg. Duration"
                  ? formatDuration(entry.value)
                  : entry.name === "Bounce Rate"
                  ? `${entry.value}%`
                  : entry.value.toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const summaryStats = data.length > 0 ? {
    totalPageViews: data.reduce((sum, d) => sum + d.pageViews, 0),
    totalVisitors: data.reduce((sum, d) => sum + d.uniqueVisitors, 0),
    avgDuration: Math.round(
      data.reduce((sum, d) => sum + d.avgSessionDuration, 0) / data.length
    ),
    avgBounceRate: (
      data.reduce((sum, d) => sum + d.bounceRate, 0) / data.length
    ).toFixed(1),
  } : {
    totalPageViews: 0,
    totalVisitors: 0,
    avgDuration: 0,
    avgBounceRate: "0",
  };

  return (
    <Card className={cn("p-6", className)} data-testid="engagement-chart">
      <div className="space-y-6">
        {/* Header with summary stats */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h3 className="text-lg font-semibold font-heading">
              Engagement Analytics
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              User behavior and session metrics
            </p>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-semibold tabular-nums">
                  {summaryStats.totalPageViews.toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground">Page Views</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-semibold tabular-nums">
                  {summaryStats.totalVisitors.toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground">Visitors</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-semibold tabular-nums">
                  {formatDuration(summaryStats.avgDuration)}
                </p>
                <p className="text-xs text-muted-foreground">Avg. Duration</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-semibold tabular-nums">
                  {summaryStats.avgBounceRate}%
                </p>
                <p className="text-xs text-muted-foreground">Bounce Rate</p>
              </div>
            </div>
          </div>
        </div>

        {/* Chart tabs */}
        <Tabs value={view} onValueChange={(v) => setView(v as MetricView)}>
          <TabsList>
            <TabsTrigger value="overview" data-testid="engagement-view-overview">
              Overview
            </TabsTrigger>
            <TabsTrigger value="sessions" data-testid="engagement-view-sessions">
              Sessions
            </TabsTrigger>
            <TabsTrigger value="duration" data-testid="engagement-view-duration">
              Duration
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-4">
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(var(--border))"
                    strokeOpacity={0.5}
                    vertical={false}
                  />
                  <XAxis
                    dataKey="period"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) =>
                      value >= 1000 ? `${(value / 1000).toFixed(0)}K` : value
                    }
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar
                    dataKey="pageViews"
                    name="Page Views"
                    fill="hsl(var(--chart-1))"
                    radius={[4, 4, 0, 0]}
                    animationDuration={800}
                  />
                  <Bar
                    dataKey="uniqueVisitors"
                    name="Unique Visitors"
                    fill="hsl(var(--chart-2))"
                    radius={[4, 4, 0, 0]}
                    animationDuration={800}
                    animationBegin={200}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="sessions" className="mt-4">
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(var(--border))"
                    strokeOpacity={0.5}
                    vertical={false}
                  />
                  <XAxis
                    dataKey="period"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="pagesPerSession"
                    name="Pages/Session"
                    stroke="hsl(var(--chart-3))"
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--chart-3))", r: 4 }}
                    animationDuration={800}
                  />
                  <Line
                    type="monotone"
                    dataKey="bounceRate"
                    name="Bounce Rate"
                    stroke="hsl(var(--chart-5))"
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--chart-5))", r: 4 }}
                    animationDuration={800}
                    animationBegin={200}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="duration" className="mt-4">
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="hsl(var(--border))"
                    strokeOpacity={0.5}
                    vertical={false}
                  />
                  <XAxis
                    dataKey="period"
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => formatDuration(value)}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar
                    dataKey="avgSessionDuration"
                    name="Avg. Duration"
                    fill="hsl(var(--chart-4))"
                    radius={[4, 4, 0, 0]}
                    animationDuration={800}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Card>
  );
}

export function EngagementChartSkeleton() {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="space-y-2">
          <div className="h-6 bg-muted rounded w-40 animate-pulse" />
          <div className="h-4 bg-muted rounded w-56 animate-pulse" />
        </div>
        <div className="flex gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-10 bg-muted rounded w-16 animate-pulse" />
          ))}
        </div>
      </div>
      <div className="h-8 bg-muted rounded w-64 mb-4 animate-pulse" />
      <div className="h-[280px] bg-muted/30 rounded animate-pulse" />
    </Card>
  );
}
