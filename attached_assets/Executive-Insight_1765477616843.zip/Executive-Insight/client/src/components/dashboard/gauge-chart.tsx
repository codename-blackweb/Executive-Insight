import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface GaugeChartProps {
  value: number;
  max?: number;
  label: string;
  sublabel?: string;
  trend?: "up" | "down" | "stable";
  size?: "sm" | "md" | "lg";
  showValue?: boolean;
  colorScheme?: "primary" | "success" | "warning" | "destructive";
  className?: string;
}

export function GaugeChart({
  value,
  max = 100,
  label,
  sublabel,
  trend,
  size = "md",
  showValue = true,
  colorScheme = "primary",
  className,
}: GaugeChartProps) {
  const percentage = Math.min(Math.max((value / max) * 100, 0), 100);
  
  // Arc calculations for half circle
  const strokeWidth = size === "sm" ? 8 : size === "md" ? 10 : 12;
  const radius = size === "sm" ? 40 : size === "md" ? 50 : 60;
  const circumference = Math.PI * radius; // Half circle
  const offset = circumference - (percentage / 100) * circumference;
  
  const viewBoxSize = (radius + strokeWidth) * 2;
  const center = radius + strokeWidth;

  const getColor = () => {
    switch (colorScheme) {
      case "success":
        return "hsl(var(--success))";
      case "warning":
        return "hsl(var(--warning))";
      case "destructive":
        return "hsl(var(--destructive))";
      default:
        return "hsl(var(--primary))";
    }
  };

  const getGradientId = `gauge-gradient-${colorScheme}-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <div
      className={cn("flex flex-col items-center", className)}
      data-testid="gauge-chart"
    >
      <div className="relative">
        <svg
          width={viewBoxSize}
          height={center + 10}
          viewBox={`0 0 ${viewBoxSize} ${center + 10}`}
          className="transform -rotate-90"
          style={{ transformOrigin: "center" }}
        >
          <defs>
            <linearGradient id={getGradientId} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={getColor()} stopOpacity={0.6} />
              <stop offset="100%" stopColor={getColor()} stopOpacity={1} />
            </linearGradient>
          </defs>
          
          {/* Background arc */}
          <path
            d={describeArc(center, center, radius, -90, 90)}
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />
          
          {/* Value arc */}
          <path
            d={describeArc(center, center, radius, -90, -90 + (180 * percentage) / 100)}
            fill="none"
            stroke={`url(#${getGradientId})`}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
            style={{
              filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.1))",
            }}
          />
        </svg>

        {/* Center content */}
        {showValue && (
          <div className="absolute inset-0 flex flex-col items-center justify-end pb-2">
            <span
              className={cn(
                "font-bold tabular-nums",
                size === "sm" && "text-xl",
                size === "md" && "text-2xl",
                size === "lg" && "text-3xl"
              )}
            >
              {percentage.toFixed(0)}%
            </span>
            {trend && (
              <div
                className={cn(
                  "flex items-center gap-1",
                  trend === "up" && "text-success",
                  trend === "down" && "text-destructive",
                  trend === "stable" && "text-muted-foreground"
                )}
              >
                {trend === "up" && <TrendingUp className="w-3 h-3" />}
                {trend === "down" && <TrendingDown className="w-3 h-3" />}
                {trend === "stable" && <Minus className="w-3 h-3" />}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Labels */}
      <div className="text-center mt-2">
        <p
          className={cn(
            "font-medium",
            size === "sm" && "text-xs",
            size === "md" && "text-sm",
            size === "lg" && "text-base"
          )}
        >
          {label}
        </p>
        {sublabel && (
          <p className="text-xs text-muted-foreground mt-0.5">{sublabel}</p>
        )}
      </div>
    </div>
  );
}

// Helper function to create SVG arc path
function polarToCartesian(
  centerX: number,
  centerY: number,
  radius: number,
  angleInDegrees: number
) {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
  return {
    x: centerX + radius * Math.cos(angleInRadians),
    y: centerY + radius * Math.sin(angleInRadians),
  };
}

function describeArc(
  x: number,
  y: number,
  radius: number,
  startAngle: number,
  endAngle: number
) {
  const start = polarToCartesian(x, y, radius, endAngle);
  const end = polarToCartesian(x, y, radius, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
  
  return [
    "M",
    start.x,
    start.y,
    "A",
    radius,
    radius,
    0,
    largeArcFlag,
    0,
    end.x,
    end.y,
  ].join(" ");
}

export function GaugeChartSkeleton({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const dimension = size === "sm" ? 96 : size === "md" ? 120 : 144;
  
  return (
    <div className="flex flex-col items-center">
      <div
        className="bg-muted rounded-t-full animate-pulse"
        style={{ width: dimension, height: dimension / 2 + 10 }}
      />
      <div className="h-4 bg-muted rounded w-20 mt-2 animate-pulse" />
    </div>
  );
}
