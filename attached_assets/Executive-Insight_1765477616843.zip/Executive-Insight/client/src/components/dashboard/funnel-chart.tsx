import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { ArrowRight, Users, Clock } from "lucide-react";
import type { RecruitmentFunnel, FunnelStage } from "@shared/schema";

interface FunnelChartProps {
  data: RecruitmentFunnel;
  className?: string;
}

export function FunnelChart({ data, className }: FunnelChartProps) {
  const maxCount = data.stages[0]?.count || 1;

  return (
    <Card className={cn("p-6", className)} data-testid="funnel-chart">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h3 className="text-lg font-semibold font-heading">
              Recruitment Funnel
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Candidate flow through hiring stages
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-2xl font-bold tabular-nums">
                {data.totalCandidates.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">Total Candidates</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-success tabular-nums">
                {data.overallConversionRate.toFixed(1)}%
              </p>
              <p className="text-xs text-muted-foreground">Overall Conversion</p>
            </div>
          </div>
        </div>

        {/* Funnel stages */}
        <div className="space-y-3">
          {data.stages.map((stage, index) => (
            <FunnelStageRow
              key={stage.id}
              stage={stage}
              index={index}
              maxCount={maxCount}
              isLast={index === data.stages.length - 1}
            />
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 pt-4 border-t border-border">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="w-3 h-3 rounded bg-primary" />
            <span>Candidates in stage</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="w-3 h-3 rounded bg-destructive/30" />
            <span>Drop-off</span>
          </div>
        </div>
      </div>
    </Card>
  );
}

interface FunnelStageRowProps {
  stage: FunnelStage;
  index: number;
  maxCount: number;
  isLast: boolean;
}

function FunnelStageRow({ stage, index, maxCount, isLast }: FunnelStageRowProps) {
  const widthPercentage = (stage.count / maxCount) * 100;
  const dropoffWidth = stage.dropoffRate > 0 ? (stage.dropoffRate / 100) * widthPercentage : 0;

  return (
    <div
      className="animate-slide-up"
      style={{ animationDelay: `${index * 100}ms` }}
      data-testid={`funnel-stage-${stage.id}`}
    >
      <div className="flex items-center gap-4 mb-2">
        <div className="w-32 flex-shrink-0">
          <p className="font-medium text-sm truncate">{stage.name}</p>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
            <Users className="w-3 h-3" />
            <span className="tabular-nums">{stage.count.toLocaleString()}</span>
          </div>
        </div>

        <div className="flex-1 relative">
          {/* Background track */}
          <div className="h-10 bg-muted rounded-md overflow-hidden relative">
            {/* Main bar */}
            <div
              className="h-full bg-gradient-to-r from-primary to-primary/80 rounded-md transition-all duration-1000 ease-out relative"
              style={{ width: `${widthPercentage}%` }}
            >
              {/* Dropoff indicator */}
              {dropoffWidth > 0 && (
                <div
                  className="absolute right-0 top-0 h-full bg-destructive/30"
                  style={{ width: `${(dropoffWidth / widthPercentage) * 100}%` }}
                />
              )}
            </div>
            
            {/* Percentage overlay */}
            <div className="absolute inset-0 flex items-center px-3">
              <span className="text-sm font-semibold text-white drop-shadow-sm">
                {stage.percentage.toFixed(1)}%
              </span>
            </div>
          </div>
        </div>

        <div className="w-28 flex-shrink-0 text-right space-y-0.5">
          <Badge
            variant={stage.conversionRate >= 70 ? "default" : stage.conversionRate >= 40 ? "secondary" : "destructive"}
            className="text-xs"
          >
            {stage.conversionRate.toFixed(0)}% conv.
          </Badge>
          <div className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{stage.avgTimeInStage}</span>
          </div>
        </div>
      </div>

      {/* Arrow connector */}
      {!isLast && (
        <div className="flex items-center justify-center py-1">
          <ArrowRight className="w-4 h-4 text-muted-foreground/50" />
          {stage.dropoffRate > 0 && (
            <span className="text-xs text-destructive ml-2">
              -{stage.dropoffRate.toFixed(1)}% dropoff
            </span>
          )}
        </div>
      )}
    </div>
  );
}

export function FunnelChartSkeleton() {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="space-y-2">
          <div className="h-6 bg-muted rounded w-40 animate-pulse" />
          <div className="h-4 bg-muted rounded w-60 animate-pulse" />
        </div>
        <div className="flex gap-4">
          <div className="h-12 bg-muted rounded w-24 animate-pulse" />
          <div className="h-12 bg-muted rounded w-24 animate-pulse" />
        </div>
      </div>
      <div className="space-y-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="h-14 bg-muted/50 rounded animate-pulse" />
        ))}
      </div>
    </Card>
  );
}
