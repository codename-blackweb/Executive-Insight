import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { MapPin, Users, Briefcase, TrendingUp } from "lucide-react";
import type { GeoData } from "@shared/schema";

interface GeoMapProps {
  data: GeoData[];
  className?: string;
}

export function GeoMap({ data, className }: GeoMapProps) {
  const totalVisitors = data.reduce((sum, d) => sum + d.visitors, 0);
  const totalApplications = data.reduce((sum, d) => sum + d.applications, 0);
  const maxVisitors = Math.max(...data.map((d) => d.visitors));

  const sortedData = [...data].sort((a, b) => b.visitors - a.visitors);

  return (
    <Card className={cn("p-6", className)} data-testid="geo-map">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h3 className="text-lg font-semibold font-heading">
              Geographic Distribution
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Visitor and application data by region
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-lg font-bold tabular-nums">
                {totalVisitors.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">Total Visitors</p>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold tabular-nums text-success">
                {totalApplications.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">Applications</p>
            </div>
          </div>
        </div>

        {/* Region list */}
        <div className="space-y-3">
          {sortedData.map((region, index) => (
            <div
              key={`${region.region}-${region.country}`}
              className={cn(
                "p-4 rounded-md border border-border bg-card/50 animate-fade-in",
                "hover:border-primary/30 transition-colors"
              )}
              style={{ animationDelay: `${index * 75}ms` }}
              data-testid={`geo-region-${region.region.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-md bg-primary/10 mt-0.5">
                    <MapPin className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-medium">{region.region}</p>
                      <Badge variant="outline" className="text-xs">
                        {region.country}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        <span className="tabular-nums">
                          {region.visitors.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Briefcase className="w-3 h-3" />
                        <span className="tabular-nums">
                          {region.applications.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        <span className="tabular-nums">
                          {region.conversionRate.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Percentage indicator */}
                <div className="text-right flex-shrink-0">
                  <p className="text-lg font-bold tabular-nums">
                    {((region.visitors / totalVisitors) * 100).toFixed(1)}%
                  </p>
                  <p className="text-xs text-muted-foreground">of traffic</p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mt-3 h-1.5 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full bg-primary transition-all duration-1000 ease-out"
                  style={{ width: `${(region.visitors / maxVisitors) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-border text-xs text-muted-foreground">
          <span>{data.length} regions tracked</span>
          <span>
            Avg. conversion: {(totalApplications / totalVisitors * 100).toFixed(2)}%
          </span>
        </div>
      </div>
    </Card>
  );
}

export function GeoMapSkeleton() {
  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <div className="h-6 bg-muted rounded w-48 animate-pulse" />
            <div className="h-4 bg-muted rounded w-64 animate-pulse" />
          </div>
          <div className="flex gap-4">
            <div className="h-12 bg-muted rounded w-20 animate-pulse" />
            <div className="h-12 bg-muted rounded w-20 animate-pulse" />
          </div>
        </div>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-24 bg-muted/50 rounded animate-pulse" />
          ))}
        </div>
      </div>
    </Card>
  );
}
