import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  AlertTriangle,
  TrendingUp,
  Lightbulb,
  Bell,
  Check,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import type { AIInsight } from "@shared/schema";

interface InsightsPanelProps {
  insights: AIInsight[];
  onDismiss?: (id: string) => void;
  className?: string;
}

export function InsightsPanel({ insights, onDismiss, className }: InsightsPanelProps) {
  const unreadInsights = insights.filter((i) => !i.isRead);
  const criticalInsights = insights.filter((i) => i.severity === "critical" || i.severity === "high");

  if (!insights.length) {
    return (
      <Card className={cn("p-6", className)} data-testid="insights-panel">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-md bg-primary/10">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-heading">AI Insights</h3>
            <p className="text-sm text-muted-foreground">
              Intelligent recommendations for your talent acquisition
            </p>
          </div>
        </div>
        <div className="flex items-center justify-center py-8 text-muted-foreground">
          <p className="text-sm">No new insights at this time</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className={cn("p-6", className)} data-testid="insights-panel">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 mb-6 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-md bg-primary/10">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-heading">AI Insights</h3>
            <p className="text-sm text-muted-foreground">
              {unreadInsights.length} new insights available
            </p>
          </div>
        </div>
        
        {criticalInsights.length > 0 && (
          <Badge variant="destructive" className="animate-pulse-soft">
            {criticalInsights.length} Critical
          </Badge>
        )}
      </div>

      {/* Insights list */}
      <div className="space-y-3">
        {insights.slice(0, 5).map((insight, index) => (
          <InsightCard
            key={insight.id}
            insight={insight}
            index={index}
            onDismiss={onDismiss}
          />
        ))}
      </div>

      {insights.length > 5 && (
        <Button variant="ghost" className="w-full mt-4" data-testid="view-all-insights">
          View all {insights.length} insights
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      )}
    </Card>
  );
}

interface InsightCardProps {
  insight: AIInsight;
  index: number;
  onDismiss?: (id: string) => void;
}

function InsightCard({ insight, index, onDismiss }: InsightCardProps) {
  const getIcon = () => {
    switch (insight.type) {
      case "anomaly":
        return <AlertTriangle className="w-4 h-4" />;
      case "recommendation":
        return <Lightbulb className="w-4 h-4" />;
      case "trend":
        return <TrendingUp className="w-4 h-4" />;
      case "alert":
        return <Bell className="w-4 h-4" />;
      default:
        return <Sparkles className="w-4 h-4" />;
    }
  };

  const getSeverityColor = () => {
    switch (insight.severity) {
      case "critical":
        return "bg-destructive/10 text-destructive border-destructive/20";
      case "high":
        return "bg-warning/10 text-warning-foreground border-warning/20";
      case "medium":
        return "bg-info/10 text-info border-info/20";
      default:
        return "bg-muted text-muted-foreground border-muted";
    }
  };

  const getTypeColor = () => {
    switch (insight.type) {
      case "anomaly":
        return "text-destructive";
      case "recommendation":
        return "text-success";
      case "trend":
        return "text-info";
      case "alert":
        return "text-warning";
      default:
        return "text-primary";
    }
  };

  return (
    <div
      className={cn(
        "p-4 rounded-md border transition-all animate-fade-in group",
        getSeverityColor(),
        insight.isRead && "opacity-60"
      )}
      style={{ animationDelay: `${index * 100}ms` }}
      data-testid={`insight-${insight.id}`}
    >
      <div className="flex items-start gap-3">
        <div className={cn("mt-0.5", getTypeColor())}>{getIcon()}</div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <h4 className="font-medium text-sm">{insight.title}</h4>
            <Badge variant="outline" className="text-xs">
              {insight.type}
            </Badge>
            {insight.metric && (
              <span className="text-xs text-muted-foreground">
                {insight.metric}
              </span>
            )}
          </div>
          
          <p className="text-sm text-muted-foreground line-clamp-2">
            {insight.description}
          </p>
          
          {insight.recommendation && (
            <p className="text-sm mt-2 font-medium">
              {insight.recommendation}
            </p>
          )}
          
          {insight.impact && (
            <p className="text-xs text-muted-foreground mt-1">
              Impact: {insight.impact}
            </p>
          )}
          
          <div className="flex items-center justify-between mt-3 gap-4">
            <span className="text-xs text-muted-foreground">
              {formatTimestamp(insight.timestamp)}
            </span>
            
            {onDismiss && !insight.isRead && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onDismiss(insight.id)}
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                data-testid={`dismiss-insight-${insight.id}`}
              >
                <Check className="w-3 h-3 mr-1" />
                Mark as read
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function formatTimestamp(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffHours / 24);

  if (diffHours < 1) return "Just now";
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
}

export function InsightsPanelSkeleton() {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-muted rounded-md animate-pulse" />
        <div className="space-y-2">
          <div className="h-5 bg-muted rounded w-24 animate-pulse" />
          <div className="h-4 bg-muted rounded w-40 animate-pulse" />
        </div>
      </div>
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-24 bg-muted/50 rounded-md animate-pulse" />
        ))}
      </div>
    </Card>
  );
}
