import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { Briefcase, Clock, DollarSign, Star, Users, UserCheck } from "lucide-react";
import type { JobCategoryMetric } from "@shared/schema";

interface JobPerformanceProps {
  data: JobCategoryMetric[];
  className?: string;
}

export function JobPerformance({ data, className }: JobPerformanceProps) {
  const sortedData = [...data].sort((a, b) => b.applicants - a.applicants);

  const totals = {
    openPositions: data.reduce((sum, d) => sum + d.openPositions, 0),
    applicants: data.reduce((sum, d) => sum + d.applicants, 0),
    hires: data.reduce((sum, d) => sum + d.hires, 0),
    avgTimeToFill: Math.round(
      data.reduce((sum, d) => sum + d.timeToFill, 0) / data.length
    ),
    avgCostPerHire: Math.round(
      data.reduce((sum, d) => sum + d.costPerHire, 0) / data.length
    ),
    avgQualityScore:
      data.reduce((sum, d) => sum + d.qualityScore, 0) / data.length,
  };

  const getQualityBadge = (score: number) => {
    if (score >= 4.5) return { variant: "default" as const, label: "Excellent" };
    if (score >= 4.0) return { variant: "secondary" as const, label: "Good" };
    if (score >= 3.5) return { variant: "outline" as const, label: "Average" };
    return { variant: "destructive" as const, label: "Below Avg" };
  };

  return (
    <Card className={cn("p-6", className)} data-testid="job-performance">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h3 className="text-lg font-semibold font-heading">
              Job Category Performance
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Recruitment metrics by department and role type
            </p>
          </div>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <SummaryCard
            icon={<Briefcase className="w-4 h-4" />}
            label="Open Positions"
            value={totals.openPositions}
            color="primary"
          />
          <SummaryCard
            icon={<Users className="w-4 h-4" />}
            label="Applicants"
            value={totals.applicants}
            color="info"
          />
          <SummaryCard
            icon={<UserCheck className="w-4 h-4" />}
            label="Hires"
            value={totals.hires}
            color="success"
          />
          <SummaryCard
            icon={<Clock className="w-4 h-4" />}
            label="Avg. Time to Fill"
            value={`${totals.avgTimeToFill}d`}
            color="warning"
          />
          <SummaryCard
            icon={<DollarSign className="w-4 h-4" />}
            label="Avg. Cost/Hire"
            value={`$${(totals.avgCostPerHire / 1000).toFixed(1)}K`}
            color="destructive"
          />
          <SummaryCard
            icon={<Star className="w-4 h-4" />}
            label="Quality Score"
            value={totals.avgQualityScore.toFixed(1)}
            color="accent"
          />
        </div>

        {/* Table */}
        <div className="rounded-md border border-border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30">
                <TableHead className="font-semibold">Category</TableHead>
                <TableHead className="text-right font-semibold">Open</TableHead>
                <TableHead className="text-right font-semibold">Applicants</TableHead>
                <TableHead className="text-right font-semibold">Hires</TableHead>
                <TableHead className="text-right font-semibold">Time to Fill</TableHead>
                <TableHead className="text-right font-semibold">Cost/Hire</TableHead>
                <TableHead className="text-right font-semibold">Quality</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedData.map((row, index) => {
                const qualityBadge = getQualityBadge(row.qualityScore);
                return (
                  <TableRow
                    key={row.category}
                    className="animate-fade-in"
                    style={{ animationDelay: `${index * 50}ms` }}
                    data-testid={`job-row-${row.category.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <TableCell className="font-medium">{row.category}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {row.openPositions}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {row.applicants.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {row.hires}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {row.timeToFill}d
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      ${(row.costPerHire / 1000).toFixed(1)}K
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant={qualityBadge.variant} className="text-xs">
                        {row.qualityScore.toFixed(1)} - {qualityBadge.label}
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </Card>
  );
}

interface SummaryCardProps {
  icon: React.ReactNode;
  label: string;
  value: number | string;
  color: "primary" | "info" | "success" | "warning" | "destructive" | "accent";
}

function SummaryCard({ icon, label, value, color }: SummaryCardProps) {
  const colorClasses = {
    primary: "bg-primary/10 text-primary",
    info: "bg-info/10 text-info",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning-foreground",
    destructive: "bg-destructive/10 text-destructive",
    accent: "bg-accent text-accent-foreground",
  };

  return (
    <div className="p-3 rounded-md border border-border bg-card/50">
      <div className="flex items-center gap-2 mb-2">
        <div className={cn("p-1.5 rounded", colorClasses[color])}>{icon}</div>
      </div>
      <p className="text-lg font-bold tabular-nums">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

export function JobPerformanceSkeleton() {
  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div className="space-y-2">
          <div className="h-6 bg-muted rounded w-48 animate-pulse" />
          <div className="h-4 bg-muted rounded w-72 animate-pulse" />
        </div>
        <div className="grid grid-cols-6 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-20 bg-muted/50 rounded animate-pulse" />
          ))}
        </div>
        <div className="h-64 bg-muted/30 rounded animate-pulse" />
      </div>
    </Card>
  );
}
