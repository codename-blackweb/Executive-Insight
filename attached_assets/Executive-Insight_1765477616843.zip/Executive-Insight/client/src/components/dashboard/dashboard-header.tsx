import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { useTheme } from "@/lib/theme";
import {
  Download,
  RefreshCw,
  Settings,
  Moon,
  Sun,
  FileText,
  FileSpreadsheet,
  Image,
  ChevronDown,
  Ship,
  Activity,
} from "lucide-react";
import type { DateRangePreset } from "@shared/schema";

interface DashboardHeaderProps {
  selectedDateRange: DateRangePreset;
  dateRangePresets: DateRangePreset[];
  onDateRangeChange: (preset: DateRangePreset) => void;
  onRefresh: () => void;
  isRefreshing?: boolean;
  lastUpdated?: string;
}

export function DashboardHeader({
  selectedDateRange,
  dateRangePresets,
  onDateRangeChange,
  onRefresh,
  isRefreshing = false,
  lastUpdated,
}: DashboardHeaderProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <header
      className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border"
      data-testid="dashboard-header"
    >
      <div className="max-w-[1920px] mx-auto px-6 h-16 flex items-center justify-between gap-4">
        {/* Logo & Title */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-md bg-primary">
              <Ship className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold font-heading">
                RCG Talent Intelligence
              </h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Top of Funnel Analytics Dashboard
              </p>
            </div>
          </div>
        </div>

        {/* Live indicator */}
        <div className="hidden md:flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-success/10 border border-success/20">
            <Activity className="w-3 h-3 text-success animate-pulse-soft" />
            <span className="text-xs font-medium text-success">Live</span>
          </div>
          {lastUpdated && (
            <span className="text-xs text-muted-foreground">
              Updated {formatLastUpdated(lastUpdated)}
            </span>
          )}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {/* Date Range Picker */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" data-testid="date-range-picker">
                {selectedDateRange.label}
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {dateRangePresets.map((preset) => (
                <DropdownMenuItem
                  key={preset.id}
                  onClick={() => onDateRangeChange(preset)}
                  className={cn(
                    selectedDateRange.id === preset.id && "bg-accent"
                  )}
                  data-testid={`date-range-${preset.id}`}
                >
                  <span className="flex-1">{preset.label}</span>
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {preset.shortLabel}
                  </Badge>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Refresh */}
          <Button
            variant="outline"
            size="icon"
            onClick={onRefresh}
            disabled={isRefreshing}
            data-testid="refresh-button"
          >
            <RefreshCw
              className={cn("w-4 h-4", isRefreshing && "animate-spin")}
            />
          </Button>

          {/* Export */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" data-testid="export-button">
                <Download className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem data-testid="export-pdf">
                <FileText className="w-4 h-4 mr-2" />
                Export as PDF
              </DropdownMenuItem>
              <DropdownMenuItem data-testid="export-excel">
                <FileSpreadsheet className="w-4 h-4 mr-2" />
                Export as Excel
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem data-testid="export-image">
                <Image className="w-4 h-4 mr-2" />
                Export as Image
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Theme Toggle */}
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            data-testid="theme-toggle"
          >
            {theme === "dark" ? (
              <Sun className="w-4 h-4" />
            ) : (
              <Moon className="w-4 h-4" />
            )}
          </Button>

          {/* Settings */}
          <Button variant="outline" size="icon" data-testid="settings-button">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}

function formatLastUpdated(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);

  if (diffSeconds < 60) return "just now";
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
}

export function DashboardHeaderSkeleton() {
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-[1920px] mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-muted rounded-md animate-pulse" />
          <div className="space-y-2">
            <div className="h-5 bg-muted rounded w-40 animate-pulse" />
            <div className="h-3 bg-muted rounded w-32 animate-pulse" />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-9 bg-muted rounded w-32 animate-pulse" />
          <div className="h-9 w-9 bg-muted rounded animate-pulse" />
          <div className="h-9 w-9 bg-muted rounded animate-pulse" />
          <div className="h-9 w-9 bg-muted rounded animate-pulse" />
        </div>
      </div>
    </header>
  );
}
