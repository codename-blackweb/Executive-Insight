import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Monitor, Smartphone, Tablet, Laptop, Globe } from "lucide-react";
import type { DeviceBreakdown as DeviceBreakdownType } from "@shared/schema";

interface DeviceBreakdownProps {
  data: DeviceBreakdownType[];
  className?: string;
}

export function DeviceBreakdown({ data, className }: DeviceBreakdownProps) {
  const totalSessions = data.reduce((sum, d) => sum + d.sessions, 0);
  const maxSessions = Math.max(...data.map((d) => d.sessions));

  const getDeviceIcon = (device: string) => {
    const lowercased = device.toLowerCase();
    if (lowercased.includes("mobile") || lowercased.includes("phone")) {
      return <Smartphone className="w-4 h-4" />;
    }
    if (lowercased.includes("tablet")) {
      return <Tablet className="w-4 h-4" />;
    }
    if (lowercased.includes("laptop")) {
      return <Laptop className="w-4 h-4" />;
    }
    if (lowercased.includes("desktop")) {
      return <Monitor className="w-4 h-4" />;
    }
    return <Globe className="w-4 h-4" />;
  };

  const getDeviceColor = (device: string) => {
    const lowercased = device.toLowerCase();
    if (lowercased.includes("mobile") || lowercased.includes("phone")) {
      return "hsl(var(--chart-2))";
    }
    if (lowercased.includes("tablet")) {
      return "hsl(var(--chart-3))";
    }
    if (lowercased.includes("desktop")) {
      return "hsl(var(--chart-1))";
    }
    return "hsl(var(--chart-4))";
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <Card className={cn("p-6", className)} data-testid="device-breakdown">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h3 className="text-lg font-semibold font-heading">Device Breakdown</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Sessions by device type and platform
          </p>
        </div>

        {/* Total indicator */}
        <div className="flex items-center justify-between p-4 rounded-md bg-muted/50">
          <span className="text-sm text-muted-foreground">Total Sessions</span>
          <span className="text-2xl font-bold tabular-nums">
            {totalSessions.toLocaleString()}
          </span>
        </div>

        {/* Device list */}
        <div className="space-y-4">
          {data.map((device, index) => (
            <div
              key={device.device}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
              data-testid={`device-${device.device.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <div className="flex items-center justify-between gap-4 mb-2">
                <div className="flex items-center gap-3">
                  <div
                    className="p-2 rounded-md"
                    style={{ backgroundColor: `${getDeviceColor(device.device)}20` }}
                  >
                    <span style={{ color: getDeviceColor(device.device) }}>
                      {getDeviceIcon(device.device)}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-sm">{device.device}</p>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="tabular-nums">
                        {device.sessions.toLocaleString()} sessions
                      </span>
                      <span>|</span>
                      <span className="tabular-nums">
                        {formatDuration(device.avgDuration)} avg
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Badge
                    variant={device.bounceRate < 40 ? "default" : device.bounceRate < 60 ? "secondary" : "destructive"}
                    className="text-xs"
                  >
                    {device.bounceRate.toFixed(0)}% bounce
                  </Badge>
                  <span className="text-lg font-bold tabular-nums w-16 text-right">
                    {device.percentage.toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000 ease-out"
                  style={{
                    width: `${(device.sessions / maxSessions) * 100}%`,
                    backgroundColor: getDeviceColor(device.device),
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 pt-4 border-t border-border">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Monitor className="w-3 h-3" />
            <span>Desktop</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Smartphone className="w-3 h-3" />
            <span>Mobile</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Tablet className="w-3 h-3" />
            <span>Tablet</span>
          </div>
        </div>
      </div>
    </Card>
  );
}

export function DeviceBreakdownSkeleton() {
  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div className="space-y-2">
          <div className="h-6 bg-muted rounded w-40 animate-pulse" />
          <div className="h-4 bg-muted rounded w-56 animate-pulse" />
        </div>
        <div className="h-16 bg-muted/50 rounded animate-pulse" />
        <div className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-16 bg-muted/50 rounded animate-pulse" />
          ))}
        </div>
      </div>
    </Card>
  );
}
