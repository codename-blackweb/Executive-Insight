import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import type { TrafficSource } from "@shared/schema";

interface DonutChartProps {
  data: TrafficSource[];
  title?: string;
  centerLabel?: string;
  centerValue?: string;
  className?: string;
}

export function DonutChart({
  data,
  title = "Traffic Sources",
  centerLabel,
  centerValue,
  className,
}: DonutChartProps) {
  const total = data.reduce((sum, item) => sum + item.visitors, 0);

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    
    const item = payload[0].payload;
    
    return (
      <div className="bg-popover border border-popover-border rounded-md p-3 shadow-lg">
        <div className="flex items-center gap-2 mb-1">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: item.color }}
          />
          <span className="font-medium">{item.name}</span>
        </div>
        <div className="text-sm text-muted-foreground">
          <span className="font-semibold tabular-nums">
            {item.visitors.toLocaleString()}
          </span>
          {" visitors "}
          <span className="text-xs">
            ({item.percentage.toFixed(1)}%)
          </span>
        </div>
      </div>
    );
  };

  const renderLegend = (props: any) => {
    const { payload } = props;
    
    return (
      <div className="flex flex-col gap-2 mt-4">
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full flex-shrink-0"
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-sm truncate">{entry.value}</span>
            </div>
            <span className="text-sm font-semibold tabular-nums">
              {entry.payload.percentage.toFixed(1)}%
            </span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Card className={cn("p-6", className)} data-testid="donut-chart">
      <h3 className="text-lg font-semibold font-heading mb-4">{title}</h3>
      
      <div className="flex items-center gap-6">
        <div className="relative w-48 h-48 flex-shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={80}
                paddingAngle={2}
                dataKey="visitors"
                nameKey="name"
                animationBegin={0}
                animationDuration={800}
              >
                {data.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    stroke="transparent"
                    className="transition-opacity hover:opacity-80"
                  />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          
          {/* Center content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-2xl font-bold tabular-nums">
              {centerValue || total.toLocaleString()}
            </span>
            <span className="text-xs text-muted-foreground">
              {centerLabel || "Total"}
            </span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex-1 min-w-0">
          {data.map((item, index) => (
            <div
              key={index}
              className="flex items-center justify-between gap-4 py-2 border-b border-border last:border-0"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-3 h-3 rounded-full flex-shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm truncate">{item.name}</span>
              </div>
              <div className="text-right flex-shrink-0">
                <span className="text-sm font-semibold tabular-nums">
                  {item.visitors.toLocaleString()}
                </span>
                <span className="text-xs text-muted-foreground ml-2">
                  ({item.percentage.toFixed(1)}%)
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}

export function DonutChartSkeleton() {
  return (
    <Card className="p-6">
      <div className="h-6 bg-muted rounded w-32 mb-4 animate-pulse" />
      <div className="flex items-center gap-6">
        <div className="w-48 h-48 rounded-full bg-muted animate-pulse" />
        <div className="flex-1 space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-8 bg-muted rounded animate-pulse" />
          ))}
        </div>
      </div>
    </Card>
  );
}
