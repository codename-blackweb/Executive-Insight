import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (kept for potential auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Dashboard Types - No database tables needed for in-memory analytics

// KPI Metric with trend data
export interface KPIMetric {
  id: string;
  label: string;
  value: number;
  formattedValue: string;
  previousValue: number;
  change: number;
  changeType: "increase" | "decrease" | "neutral";
  trend: number[]; // Sparkline data points (30 days)
  target?: number;
  unit?: string;
}

// Traffic source data
export interface TrafficSource {
  name: string;
  visitors: number;
  percentage: number;
  color: string;
}

// Time series data point
export interface TimeSeriesPoint {
  date: string;
  value: number;
  label?: string;
}

// Multi-series time data
export interface MultiSeriesData {
  name: string;
  data: TimeSeriesPoint[];
  color: string;
}

// Funnel stage
export interface FunnelStage {
  id: string;
  name: string;
  count: number;
  percentage: number;
  conversionRate: number;
  dropoffRate: number;
  avgTimeInStage: string;
}

// Recruitment funnel data
export interface RecruitmentFunnel {
  stages: FunnelStage[];
  totalCandidates: number;
  overallConversionRate: number;
}

// Shareholder metrics
export interface ShareholderMetric {
  id: string;
  label: string;
  value: number;
  formattedValue: string;
  target: number;
  progress: number;
  trend: "up" | "down" | "stable";
  category: "roi" | "efficiency" | "cost" | "quality";
}

// AI-generated insight
export interface AIInsight {
  id: string;
  type: "anomaly" | "recommendation" | "trend" | "alert";
  severity: "low" | "medium" | "high" | "critical";
  title: string;
  description: string;
  metric?: string;
  impact?: string;
  recommendation?: string;
  timestamp: string;
  isRead: boolean;
}

// Engagement metric
export interface EngagementMetric {
  period: string;
  pageViews: number;
  uniqueVisitors: number;
  avgSessionDuration: number;
  bounceRate: number;
  pagesPerSession: number;
}

// Device/Platform breakdown
export interface DeviceBreakdown {
  device: string;
  sessions: number;
  percentage: number;
  avgDuration: number;
  bounceRate: number;
}

// Geographic data
export interface GeoData {
  region: string;
  country: string;
  visitors: number;
  applications: number;
  conversionRate: number;
}

// Job category performance
export interface JobCategoryMetric {
  category: string;
  openPositions: number;
  applicants: number;
  hires: number;
  timeToFill: number;
  costPerHire: number;
  qualityScore: number;
}

// Date range preset
export interface DateRangePreset {
  id: string;
  label: string;
  shortLabel: string;
  days: number;
}

// Dashboard filter state
export interface DashboardFilters {
  dateRange: DateRangePreset;
  department?: string;
  jobCategory?: string;
  location?: string;
  source?: string;
}

// Complete dashboard data
export interface DashboardData {
  kpis: KPIMetric[];
  trafficSources: TrafficSource[];
  trafficTrend: MultiSeriesData[];
  recruitmentFunnel: RecruitmentFunnel;
  shareholderMetrics: ShareholderMetric[];
  insights: AIInsight[];
  engagementMetrics: EngagementMetric[];
  deviceBreakdown: DeviceBreakdown[];
  geoData: GeoData[];
  jobCategories: JobCategoryMetric[];
  lastUpdated: string;
}

// API Response wrapper
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  error?: string;
  timestamp: string;
}
